import React from 'react';
import {AbsoluteFill, Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig, type InteractivitySchema} from 'remotion';
import './fonts';

export const COLORS={green:'#123e2e',mint:'#a8e4b9',paper:'#f3f1e9',ink:'#081d15'};
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const ease={...clamp,easing:Easing.bezier(.19,1,.22,1)};

export const Mark=({dark=false,size=94}:{dark?:boolean;size?:number})=>(
 <svg width={size} height={size} viewBox="0 0 120 120" aria-label="Belcam Studio">
  <rect width="120" height="120" rx="27" fill={dark?'#f3f1e9':'#123e2e'}/>
  <path d="M34 27V94H63C90 94 92 58 64 58H34M34 27H62C86 27 88 58 62 58" fill="none" stroke={dark?'#123e2e':'#f3f1e9'} strokeWidth="13" strokeLinejoin="round" strokeLinecap="round"/>
  <path d="M69 28C93 36 87 59 67 61" fill="none" stroke="#a8e4b9" strokeWidth="8.5" strokeLinecap="round"/>
  <circle cx="62" cy="61" r="6" fill="#a8e4b9"/><circle cx="60" cy="59" r="1.7" fill="#fff"/>
 </svg>
);

export const Brand=({dark=false,large=false}:{dark?:boolean;large?:boolean})=>(
 <div style={{display:'flex',alignItems:'center',gap:large?26:18,color:dark?'#f3f1e9':'#123e2e'}}>
  <Mark dark={dark} size={large?120:82}/>
  <div style={{fontFamily:'Arial, Helvetica, sans-serif',fontSize:large?53:37,fontWeight:700,lineHeight:.94,letterSpacing:-1.9}}>Belcam<br/>Studio</div>
 </div>
);

export const Grain=()=> <AbsoluteFill style={{pointerEvents:'none',mixBlendMode:'multiply',opacity:.12}}>
 <svg width="100%" height="100%"><filter id="paper-grain"><feTurbulence type="fractalNoise" baseFrequency=".7" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter><rect width="100%" height="100%" filter="url(#paper-grain)" opacity=".7"/></svg>
</AbsoluteFill>;

export const Backdrop=({dark=false}:{dark?:boolean})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{background:dark?'#0a241a':'#f3f1e9',overflow:'hidden'}}>
  <AbsoluteFill style={{background:dark?'radial-gradient(ellipse at 78% 52%,#29503a 0%,#102d21 38%,#071910 90%)':'radial-gradient(ellipse at 65% 40%,#fffdf4 0%,#f1eee4 58%,#d6d4c9 100%)'}}/>
  <div style={{position:'absolute',left:-600,top:-650,width:2100,height:2600,rotate:'-29deg',translate:interpolate(frame,[0,12*fps],['-120px 0px','180px 80px'],clamp),background:dark?'repeating-linear-gradient(90deg,transparent 0px,transparent 180px,rgba(196,239,198,.07) 220px,rgba(196,239,198,.07) 390px,transparent 430px,transparent 680px)':'repeating-linear-gradient(90deg,transparent 0px,transparent 290px,rgba(35,53,38,.09) 330px,rgba(35,53,38,.09) 370px,transparent 420px,transparent 760px)',filter:'blur(20px)'}}/>
  <Grain/>
 </AbsoluteFill>;
};

type TitleProps={children:string;dark:boolean;accent:boolean;size:number;style?:React.CSSProperties};
const TitleInner=({children,dark,accent,size,style}:TitleProps)=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <Interactive.Div style={{position:'absolute',width:920,height:size*1.65,overflow:'hidden',...style}}>
  <div style={{fontFamily:'Belcam Display',fontWeight:400,fontSize:size,lineHeight:1.12,letterSpacing:-1.8,whiteSpace:'pre-line',padding:'20px 0 25px',backgroundImage:dark?`linear-gradient(112deg,${accent?'#a8e4b9':'#f3f1e9'} 10%,${accent?'#d7f4d7':'#fffef8'} 43%,${accent?'#90b99c':'#bec9b9'} 52%,${accent?'#a8e4b9':'#f3f1e9'} 70%)`:'linear-gradient(112deg,#123e2e 10%,#123e2e 42%,#42734e 49%,#123e2e 61%)',backgroundSize:'250% 100%',backgroundPosition:`${interpolate(frame,[0,7*fps],[100,-50],clamp)}% 0%`,WebkitBackgroundClip:'text',backgroundClip:'text',color:'transparent',translate:interpolate(frame,[0,.85*fps],['0px 170px','0px 0px'],ease),opacity:interpolate(frame,[0,.23*fps],[0,1],clamp)}}>{children}</div>
 </Interactive.Div>;
};
const titleSchema={children:{type:'text-content',default:'',description:'Título'},dark:{type:'boolean',default:false,description:'Fundo escuro'},accent:{type:'boolean',default:false,description:'Destaque menta'},size:{type:'number',default:130,description:'Tamanho',min:60,max:220,hiddenFromList:false}} as const satisfies InteractivitySchema;
export const Title=Interactive.withSchema({Component:TitleInner,componentName:'<Title>',schema:titleSchema,wrapInSequence:true});

export const LightSweep=({dark=false}:{dark?:boolean})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{pointerEvents:'none',mixBlendMode:dark?'screen':'multiply',opacity:dark?.18:.065,background:`linear-gradient(112deg,transparent 35%,${dark?'#b7e8ad':'#254e32'} 50%,transparent 65%)`,backgroundSize:'250% 100%',backgroundPosition:`${interpolate(frame,[0,9*fps],[115,-85],clamp)}% 0%`}}/>;
};

export const Support=({children,dark=false,top=1510}:{children:React.ReactNode;dark?:boolean;top?:number})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <Interactive.Div name="Texto de apoio" premountFor={fps} style={{position:'absolute',left:90,top,width:880,fontFamily:'Belcam Text',fontSize:49,fontWeight:600,lineHeight:1.15,color:dark?'#e4ebdb':'#123e2e',opacity:interpolate(frame,[2.7*fps,3.4*fps],[0,1],clamp),translate:interpolate(frame,[2.7*fps,3.5*fps],['0px 24px','0px 0px'],ease)}}>{children}</Interactive.Div>;
};
