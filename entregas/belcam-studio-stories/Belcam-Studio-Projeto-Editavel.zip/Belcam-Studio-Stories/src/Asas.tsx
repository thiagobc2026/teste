import React from 'react';
import {AbsoluteFill, CanvasImage, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Backdrop,Brand,Title,Support,LightSweep,Grain,clamp,ease} from './Kit';

const FilmStrip=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <svg viewBox="0 0 1600 360" style={{position:'absolute',left:-230,top:1110,width:1600,height:360,rotate:'-18deg',translate:interpolate(frame,[0,8.5*fps],['-450px 160px','180px 0px'],ease),opacity:.35}}>
  <path d="M-100 180C180-160 450 410 850 150S1450 20 1800 200" fill="none" stroke="#123e2e" strokeWidth="180"/>
  <path d="M-100 180C180-160 450 410 850 150S1450 20 1800 200" fill="none" stroke="#8cb095" strokeWidth="128" strokeDasharray="120 25"/>
  <path d="M-100 107C180-233 450 337 850 77S1450-53 1800 127" fill="none" stroke="#f3f1e9" strokeWidth="11" strokeDasharray="12 22"/>
  <path d="M-100 253C180-87 450 483 850 223S1450 93 1800 273" fill="none" stroke="#f3f1e9" strokeWidth="11" strokeDasharray="12 22"/>
 </svg>;
};

export const Asas=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{overflow:'hidden'}}>
  <Backdrop/>
  <Interactive.Div name="Assinatura" premountFor={fps} style={{position:'absolute',left:90,top:205}}><Brand/></Interactive.Div>
  <FilmStrip/>
  <div style={{position:'absolute',left:130,top:1350,width:720,height:100,borderRadius:'50%',background:'#173c25',filter:'blur(45px)',opacity:interpolate(frame,[.2*fps,2*fps,8.5*fps],[0,.16,.1],clamp),scale:interpolate(frame,[0,8.5*fps],[.8,1.03],clamp)}}/>
  <Interactive.Div name="Ave de película" premountFor={fps} style={{position:'absolute',left:40,top:780,width:1020,height:770,translate:interpolate(frame,[0,1.6*fps,4.8*fps,8.5*fps],['-680px 260px','0px 0px','24px -45px','-6px -5px'],ease),rotate:interpolate(frame,[0,1.6*fps,4.8*fps,8.5*fps],['-18deg','-3deg','2deg','-2deg'],ease),scale:interpolate(frame,[0,1.8*fps,8.5*fps],[.76,.96,1.01],{...ease,output:'perceptual-scale'})}}>
   <CanvasImage name="Origami" src={staticFile('assets/crane.png')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'contain',filter:'drop-shadow(20px 35px 24px rgba(22,47,30,.17))'}}/>
  </Interactive.Div>
  <Title name="Título 1" from={.2*fps} premountFor={fps} dark={false} accent={false} size={160} style={{left:90,top:355}}>DÊ ASAS</Title>
  <Title name="Título 2" from={.7*fps} premountFor={fps} dark={false} accent={false} size={113} style={{left:90,top:555}}>À SUA HISTÓRIA.</Title>
  <Support top={1540}>Vídeos que levam<br/>sua marca além.</Support>
  <LightSweep/>
  <Grain/>
 </AbsoluteFill>;
};
