import React from 'react';
import {AbsoluteFill, CanvasImage, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Backdrop,Brand,Title,Support,LightSweep,Grain,clamp,ease} from './Kit';

const Ribbon=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 const phase=frame/fps*.35;
 const left:string[]=[];const right:string[]=[];
 for(let i=0;i<=65;i++){
  const t=i/65;const x=690-430*t+63*Math.sin(t*Math.PI*3+phase);const y=980+540*t;
  const half=52+65*Math.sin(t*Math.PI*.85);left.push(`${x-half},${y}`);right.unshift(`${x+half},${y+24*Math.sin(t*7)}`);
 }
 return <svg width={1080} height={1920} style={{position:'absolute',inset:0,filter:'drop-shadow(22px 29px 19px rgba(0,0,0,.22))'}}>
  <defs>
   <linearGradient id="fold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#eeeadd"/><stop offset=".16" stopColor="#fffdf1"/><stop offset=".35" stopColor="#99b999"/><stop offset=".47" stopColor="#375e45"/><stop offset=".58" stopColor="#d6dec8"/><stop offset=".72" stopColor="#fffbed"/><stop offset=".93" stopColor="#a6bea1"/><stop offset="1" stopColor="#31563f"/></linearGradient>
   <clipPath id="ribbon-reveal"><rect x="0" y="940" width="1080" height={interpolate(frame,[.95*fps,3.4*fps],[0,700],ease)}/></clipPath>
  </defs>
  <g clipPath="url(#ribbon-reveal)"><path d={`M${left.join('L')}L${right.join('L')}Z`} fill="url(#fold)" stroke="#dce4cd" strokeWidth="1.5"/></g>
 </svg>;
};

export const Moldura=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{overflow:'hidden'}}>
  <Backdrop dark/>
  <Interactive.Div name="Assinatura" premountFor={fps} style={{position:'absolute',left:90,top:205}}><Brand dark/></Interactive.Div>
  <div style={{position:'absolute',left:290,top:730,width:650,height:780,background:'radial-gradient(ellipse,rgba(210,233,177,.29),transparent 66%)',opacity:interpolate(frame,[.3*fps,2.5*fps],[0,1],ease),scale:interpolate(frame,[1*fps,8.5*fps],[.6,1.4],clamp)}}/>
  <Interactive.Div name="Moldura em perspectiva" premountFor={fps} style={{position:'absolute',left:295,top:745,width:645,height:860,translate:interpolate(frame,[0,1.6*fps],['160px 140px','0px 0px'],ease),rotate:interpolate(frame,[0,1.7*fps,8.5*fps],['8deg','0deg','-2deg'],ease),opacity:interpolate(frame,[0,.6*fps],[0,1],clamp)}}>
   <div style={{position:'absolute',left:145,top:235,width:340,height:430,background:'linear-gradient(135deg,#456d4d,#eff1d8)',clipPath:'polygon(0 19%,100% 0,100% 100%,0 96%)',opacity:interpolate(frame,[.6*fps,2*fps],[0,.95],ease)}}/>
   <CanvasImage name="Madeira pintada" src={staticFile('assets/frame.png')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'contain',filter:'drop-shadow(28px 33px 25px rgba(0,0,0,.3))'}}/>
  </Interactive.Div>
  <Ribbon/>
  <Title name="Título 1" from={.2*fps} premountFor={fps} dark accent={false} size={133} style={{left:90,top:355}}>PENSE ALÉM</Title>
  <Title name="Título 2" from={.7*fps} premountFor={fps} dark accent size={129} style={{left:90,top:520}}>DA MOLDURA.</Title>
  <Support top={1605} dark>Criação que abre<br/>novas possibilidades.</Support>
  <LightSweep dark/>
  <Grain/>
 </AbsoluteFill>;
};
