import React from 'react';
import {AbsoluteFill, CanvasImage, Interactive, interpolate, random, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Backdrop,Brand,Title,Support,LightSweep,Grain,clamp,ease} from './Kit';

const Paper=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
 return <svg viewBox="0 0 600 850" style={{position:'absolute',inset:0,width:600,height:850,opacity:interpolate(frame,[1*fps,1.5*fps,5.3*fps,6*fps],[0,.95,.95,0],clamp)}}>
  {Array.from({length:46},(_,i)=>{
   const r=random('paper'+i),r2=random('pos'+i);const progress=((Math.max(0,t-1.1)*.47+r)%1);
   const y=250+progress*350;const w=interpolate(y,[250,350,430,600],[105,65,5,100],clamp);const x=300+(r2-.5)*w*2;
   const size=12+random(i+10)*13;
   return <rect key={i} x={x} y={y} width={size} height={size} fill={i%3?'#8fc49d':'#365b3c'} stroke="#cedfbc" strokeWidth=".8" transform={`rotate(${r*300+t*35},${x+size/2},${y+size/2})`}/>;
  })}
 </svg>;
};

const Flutter=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 const flap=18+Math.sin(frame/fps*8)*14;
 return <div style={{width:'100%',height:'100%',perspective:1200}}>
  <CanvasImage src={staticFile('assets/butterfly.png')} premountFor={fps} style={{position:'absolute',width:'100%',height:'100%',objectFit:'contain',clipPath:'polygon(0 0,51.5% 0,51.5% 100%,0 100%)',transformOrigin:'51.5% 54%',transform:`rotateY(${flap}deg)`}}/>
  <CanvasImage src={staticFile('assets/butterfly.png')} premountFor={fps} style={{position:'absolute',width:'100%',height:'100%',objectFit:'contain',clipPath:'polygon(51.4% 0,100% 0,100% 100%,51.4% 100%)',transformOrigin:'51.5% 54%',transform:`rotateY(${-flap}deg)`}}/>
 </div>;
};

export const Tempo=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{overflow:'hidden'}}>
  <Backdrop/>
  <Interactive.Div name="Assinatura" premountFor={fps} style={{position:'absolute',left:90,top:205}}><Brand/></Interactive.Div>
  <Interactive.Div name="Ampulheta e papéis" premountFor={fps} style={{position:'absolute',left:240,top:735,width:600,height:850,rotate:interpolate(frame,[0,1.2*fps],['-18deg','0deg'],ease),translate:interpolate(frame,[0,1.4*fps,5.5*fps,6.4*fps],['0px 180px','0px 0px','0px 0px','0px 90px'],ease),opacity:interpolate(frame,[0,.6*fps,5.3*fps,6.2*fps],[0,1,1,0],clamp)}}>
   <CanvasImage name="Vidro e madeira" src={staticFile('assets/hourglass.png')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'contain',filter:'drop-shadow(15px 25px 15px rgba(27,51,34,.13))'}}/>
   <Paper/>
  </Interactive.Div>
  <Interactive.Div name="Borboleta de papel" premountFor={fps} style={{position:'absolute',left:180,top:900,width:720,height:550,translate:interpolate(frame,[2*fps,4*fps,5.5*fps,6.6*fps,8.5*fps],['0px 220px','0px 190px','0px 180px','25px 0px','-10px -25px'],ease),scale:interpolate(frame,[2*fps,4.5*fps,5.5*fps,6.5*fps],[.04,.28,.28,1],{...ease,output:'perceptual-scale'}),rotate:interpolate(frame,[2*fps,5.5*fps,6.7*fps,8.5*fps],['8deg','-3deg','-8deg','4deg'],ease),opacity:interpolate(frame,[2*fps,2.8*fps],[0,1],clamp),filter:'drop-shadow(13px 23px 18px rgba(28,59,33,.18))'}}><Flutter/></Interactive.Div>
  <Title name="Título 1" from={.2*fps} premountFor={fps} dark={false} accent={false} size={159} style={{left:90,top:355}}>IDEIAS</Title>
  <Title name="Título 2" from={.7*fps} premountFor={fps} dark={false} accent={false} size={134} style={{left:90,top:548}}>GANHAM VIDA.</Title>
  <Support top={1590}>Animação que transforma<br/>conceitos em histórias.</Support>
  <LightSweep/>
  <Grain/>
 </AbsoluteFill>;
};
