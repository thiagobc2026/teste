import React from 'react';
import {Composition,Folder} from 'remotion';
import {AsasStory,MolduraStory,TempoStory} from './Stories';
import {Asas} from './Asas';
import {Moldura} from './Moldura';
import {Tempo} from './Tempo';
import {Ending} from './Ending';
import {Title} from './Kit';
export const RemotionRoot=()=> <>
 <Composition id="Belcam-Asas" component={AsasStory} width={1080} height={1920} fps={30} durationInFrames={360}/>
 <Composition id="Belcam-Moldura" component={MolduraStory} width={1080} height={1920} fps={30} durationInFrames={360}/>
 <Composition id="Belcam-Tempo" component={TempoStory} width={1080} height={1920} fps={30} durationInFrames={360}/>
 <Folder name="Cenas">
  <Composition id="Cena-Asas" component={Asas} width={1080} height={1920} fps={30} durationInFrames={273}/>
  <Composition id="Cena-Moldura" component={Moldura} width={1080} height={1920} fps={30} durationInFrames={273}/>
  <Composition id="Cena-Tempo" component={Tempo} width={1080} height={1920} fps={30} durationInFrames={273}/>
  <Composition id="Cena-Assinatura" component={Ending} width={1080} height={1920} fps={30} durationInFrames={105}/>
  <Composition id="Titulo" component={Title} width={1080} height={1920} fps={30} durationInFrames={120} defaultProps={{children:'SUA MARCA.',dark:false,accent:false,size:145,style:{left:90,top:500}}}/>
 </Folder>
</>;
