import React from 'react';
import {AbsoluteFill, Interactive, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {Backdrop,Brand,Title,LightSweep,Grain,clamp,ease} from './Kit';

export const Ending=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{clipPath:`inset(${interpolate(frame,[0,.55*fps],[100,0],ease)}% 0 0 0)`}}>
  <Backdrop dark/>
  <Interactive.Div name="Marca Belcam Studio" premountFor={fps} style={{position:'absolute',left:90,top:450,translate:interpolate(frame,[.4*fps,1*fps],['0px 45px','0px 0px'],ease),opacity:interpolate(frame,[.4*fps,.85*fps],[0,1],clamp)}}><Brand dark large/></Interactive.Div>
  <Title name="Assinatura 1" from={.55*fps} premountFor={fps} dark accent={false} size={145} style={{left:90,top:730}}>SUA MARCA.</Title>
  <Title name="Assinatura 2" from={.8*fps} premountFor={fps} dark accent size={106} style={{left:90,top:930}}>EM MOVIMENTO.</Title>
  <Interactive.Div name="Serviços" premountFor={fps} style={{position:'absolute',left:94,top:1260,width:890,fontFamily:'Belcam Text',fontSize:48,lineHeight:1.3,color:'#e2e9da',opacity:interpolate(frame,[1.15*fps,1.7*fps],[0,1],clamp)}}>Vídeos personalizados.<br/>Animações. Design. Personagens.</Interactive.Div>
  <LightSweep dark/>
  <Grain/>
 </AbsoluteFill>;
};
