import {loadFont} from '@remotion/fonts';
import {staticFile} from 'remotion';
loadFont({family:'Belcam Display',url:staticFile('fonts/Anton-Regular.ttf'),weight:'400'});
loadFont({family:'Belcam Text',url:staticFile('fonts/BarlowCondensed-SemiBold.ttf'),weight:'600'});
