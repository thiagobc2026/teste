import React from 'react';
import {Audio} from '@remotion/media';
import {AbsoluteFill,Sequence,staticFile,useVideoConfig} from 'remotion';
import {Asas} from './Asas';
import {Moldura} from './Moldura';
import {Tempo} from './Tempo';
import {Ending} from './Ending';

export const AsasStory=()=>{const {fps}=useVideoConfig();return <AbsoluteFill>
 <Sequence name="Dê asas à sua história" durationInFrames={9.1*fps} premountFor={fps}><Asas/></Sequence>
 <Sequence name="Assinatura final" from={8.5*fps} durationInFrames={3.5*fps} premountFor={fps}><Ending/></Sequence>
 <Audio name="Trilha original — Asas" src={staticFile('audio/asas.wav')} premountFor={fps}/>
</AbsoluteFill>;};
export const MolduraStory=()=>{const {fps}=useVideoConfig();return <AbsoluteFill>
 <Sequence name="Pense além da moldura" durationInFrames={9.1*fps} premountFor={fps}><Moldura/></Sequence>
 <Sequence name="Assinatura final" from={8.5*fps} durationInFrames={3.5*fps} premountFor={fps}><Ending/></Sequence>
 <Audio name="Trilha original — Moldura" src={staticFile('audio/moldura.wav')} premountFor={fps}/>
</AbsoluteFill>;};
export const TempoStory=()=>{const {fps}=useVideoConfig();return <AbsoluteFill>
 <Sequence name="Ideias ganham vida" durationInFrames={9.1*fps} premountFor={fps}><Tempo/></Sequence>
 <Sequence name="Assinatura final" from={8.5*fps} durationInFrames={3.5*fps} premountFor={fps}><Ending/></Sequence>
 <Audio name="Trilha original — Tempo" src={staticFile('audio/tempo.wav')} premountFor={fps}/>
</AbsoluteFill>;};
