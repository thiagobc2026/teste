import {Config} from '@remotion/cli/config';
Config.setCodec('h264');
Config.setCrf(18);
Config.setPixelFormat('yuv420p');
Config.setColorSpace('bt709');
Config.setConcurrency(2);
if (process.env.BELCAM_CHROME) Config.setBrowserExecutable(process.env.BELCAM_CHROME);
