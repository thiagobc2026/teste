"""Original synthesized music and sound design; no external recordings."""
from pathlib import Path
import wave
import numpy as np

SR=48000
DURATION=12
N=SR*DURATION
DEST=Path(__file__).parent/'public'/'audio'
DEST.mkdir(parents=True,exist_ok=True)

def score(name,seed,transpose):
    rng=np.random.default_rng(seed)
    bus=np.zeros((N,2),dtype=np.float64)
    def put(signal,start,level=1,pan=0):
        first=int(start*SR);last=min(N,first+len(signal));signal=signal[:last-first]*level
        if last<=first:return
        bus[first:last,0]+=signal*np.sqrt((1-pan)/2)
        bus[first:last,1]+=signal*np.sqrt((1+pan)/2)
    def note(freq,length=1.8):
        t=np.arange(int(SR*length))/SR
        envelope=(1-np.exp(-t*95))*np.exp(-t*2.5)
        return envelope*(np.sin(2*np.pi*freq*t)+.25*np.sin(2*np.pi*freq*2*t)*np.exp(-t*3)+.07*np.sin(2*np.pi*freq*4*t)*np.exp(-t*8))
    t=np.arange(N)/SR
    fade=np.minimum(t/.8,1)*np.minimum((DURATION-t)/1.6,1)
    for f in [82.4069,164.8138,246.9417]:
        put(np.sin(2*np.pi*f*transpose*t+.14*np.sin(t*1.1))*fade,0,.012)
    phrase=[329.63,493.88,392.00,587.33,493.88,392.00,329.63,293.66]
    for i,f in enumerate(phrase):
        put(note(f*transpose),.22+i*.89,.086,(-.2 if i%2 else .2))
    for i,f in enumerate([164.81,246.94,329.63,392.00]):
        put(note(f*transpose,2.8),9.05+i*.11,.076,(i-1.5)*.1)
    for time,length,level in [(.06,.65,.026),(.7,.55,.018),(2.7,.7,.016),(5.5,.8,.023),(8.5,.65,.04)]:
        count=int(length*SR);u=np.arange(count)/SR
        noise=rng.normal(0,1,count)
        spectrum=np.fft.rfft(noise);hz=np.fft.rfftfreq(count,1/SR)
        spectrum*=np.exp(-(hz/3500)**2)*(1-np.exp(-(hz/450)**2))
        air=np.fft.irfft(spectrum,n=count)
        air*=np.sin(np.pi*u/length)**2
        put(air,time,level,-.1)
    # Quiet tactile clicks under the first two typography reveals.
    for time in [.24,.74,9.15]:
        u=np.arange(int(.09*SR))/SR
        put(rng.normal(0,1,len(u))*np.exp(-u*90),time,.018)
    bus*=np.minimum(np.arange(N)/SR/.04,1)[:,None]
    bus*=np.minimum((N-np.arange(N))/SR/.45,1)[:,None]
    bus=np.tanh(bus*1.7)*2
    peak=float(abs(bus).max());rms=float(np.sqrt((bus*bus).mean()))
    with wave.open(str(DEST/(name+'.wav')),'wb') as file:
        file.setnchannels(2);file.setsampwidth(2);file.setframerate(SR)
        file.writeframes((bus*32767).astype('<i2').tobytes())
    print(name,'seconds',DURATION,'peak_dB',round(20*np.log10(peak),1),'rms_dB',round(20*np.log10(rms),1))

score('asas',19,1)
score('moldura',20,2**(-2/12))
score('tempo',21,2**(3/12))
