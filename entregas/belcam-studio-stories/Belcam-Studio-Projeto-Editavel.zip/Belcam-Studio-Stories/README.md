# Belcam Studio — Stories em motion

Três filmes verticais de 12 segundos, 1080 × 1920 pixels, 30 fps, com trilha original e efeitos discretos. Sem locução. A mensagem também funciona sem áudio.

## Composições

| ID | Conceito |
| --- | --- |
| `Belcam-Asas` | Ave de origami feita de película: vídeos que levam sua marca além. |
| `Belcam-Moldura` | Fita de papel atravessando uma moldura: novas possibilidades de criação. |
| `Belcam-Tempo` | Papéis se transformando em uma borboleta: animação que dá vida às ideias. |

O encerramento traz “Sua marca. Em movimento.” e a assinatura Belcam Studio.

## Abrir e editar

Requer Node.js 20 ou superior.

```bash
npm ci
npm run studio
```

O Studio informa o endereço local para abrir no navegador. Os três filmes e suas cenas aparecem na lista de composições. Títulos, objetos, luz, textura e som estão organizados em camadas. As fontes e os materiais utilizados estão incluídos em `public/`.

## Exportar

```bash
npm run check
npm run render:asas
npm run render:moldura
npm run render:tempo
```

Os arquivos MP4 são gravados em `out/`. O Remotion pode baixar o navegador necessário na primeira exportação. Para usar um Chromium já instalado, defina `BELCAM_CHROME` com o caminho do executável.

## Conteúdo do projeto

- `src/Asas.tsx`, `src/Moldura.tsx`, `src/Tempo.tsx`: cenas principais.
- `src/Ending.tsx`: encerramento compartilhado.
- `src/Kit.tsx`: marca vetorial, tipografia, fundos, iluminação e textura.
- `src/Stories.tsx`: montagem e áudio de cada filme.
- `public/assets/`: objetos isolados com transparência.
- `public/fonts/`: Anton e Barlow Condensed, com licenças SIL OFL.
- `public/audio/`: trilhas originais, sem gravações de terceiros.
- `make_audio.py`: síntese das trilhas; depende de NumPy e não é necessário para abrir ou renderizar o projeto.

As cenas preservam margens laterais e espaços para a interface do Instagram. Os arquivos exportados usam H.264, yuv420p e áudio AAC estéreo.
